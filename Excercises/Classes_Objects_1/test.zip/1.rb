puts "Hello".class
puts 5.class
puts [1, 2, 3].class
